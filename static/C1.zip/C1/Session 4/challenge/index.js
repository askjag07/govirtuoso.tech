/*
 *    ______   __                  __  __
 *   /      \ /  |                /  |/  |
 *  /$$$$$$  |$$ |____    ______  $$ |$$ |  ______   _______    ______    ______
 *  $$ |  $$/ $$      \  /      \ $$ |$$ | /      \ /       \  /      \  /      \
 *  $$ |      $$$$$$$  | $$$$$$  |$$ |$$ |/$$$$$$  |$$$$$$$  |/$$$$$$  |/$$$$$$  |
 *  $$ |   __ $$ |  $$ | /    $$ |$$ |$$ |$$    $$ |$$ |  $$ |$$ |  $$ |$$    $$ |
 *  $$ \__/  |$$ |  $$ |/$$$$$$$ |$$ |$$ |$$$$$$$$/ $$ |  $$ |$$ \__$$ |$$$$$$$$/
 *  $$    $$/ $$ |  $$ |$$    $$ |$$ |$$ |$$       |$$ |  $$ |$$    $$ |$$       |
 *   $$$$$$/  $$/   $$/  $$$$$$$/ $$/ $$/  $$$$$$$/ $$/   $$/  $$$$$$$ | $$$$$$$/
 *                                                            /  \__$$ |
 *                                                            $$    $$/
 *                                                             $$$$$$/
 *
 *  Send your finished challenge to askjag07@gmail.com. The most creative projects will be showcased towards the end of the course.
 *
 *  GOALS
 *  1. Improve the UI of the program from the classwork with your own creativity. Good luck!
 *
 *
 *
 *  INSTRUCTIONS
 *  Use HTML and the Bulma framework to make a cool UI. Refer to the link in the index.html file. If you need any help, call me.
 */
