/*
 *    ______   __                  __  __
 *   /      \ /  |                /  |/  |
 *  /$$$$$$  |$$ |____    ______  $$ |$$ |  ______   _______    ______    ______
 *  $$ |  $$/ $$      \  /      \ $$ |$$ | /      \ /       \  /      \  /      \
 *  $$ |      $$$$$$$  | $$$$$$  |$$ |$$ |/$$$$$$  |$$$$$$$  |/$$$$$$  |/$$$$$$  |
 *  $$ |   __ $$ |  $$ | /    $$ |$$ |$$ |$$    $$ |$$ |  $$ |$$ |  $$ |$$    $$ |
 *  $$ \__/  |$$ |  $$ |/$$$$$$$ |$$ |$$ |$$$$$$$$/ $$ |  $$ |$$ \__$$ |$$$$$$$$/
 *  $$    $$/ $$ |  $$ |$$    $$ |$$ |$$ |$$       |$$ |  $$ |$$    $$ |$$       |
 *   $$$$$$/  $$/   $$/  $$$$$$$/ $$/ $$/  $$$$$$$/ $$/   $$/  $$$$$$$ | $$$$$$$/
 *                                                            /  \__$$ |
 *                                                            $$    $$/
 *                                                             $$$$$$/
 *
 *  Send your finished challenge to askjag07@gmail.com. The most creative projects will be showcased at https://govirtuoso.org.
 *
 *  GOALS
 *  1. Improve the program from the classwork with your own creativity. Add a hat, teeth, horns, etc. Good luck!
 *
 *
 *
 *  INSTRUCTIONS
 *  Refer to the code from the the classwork. If you need any help, call me.
 */
